# OAuth Video -> The Repository for the Front-End of the OAuth2.0 Project Video

## Introduction

This is the Front-End repository for the code we build in the Passport OAuth2.0 Video

Video link -> https://www.youtube.com/watch?v=cD17CYA1dck&ab_channel=NathanielWoodbury

## For Development
* Switch to the "Development" branch (git rebase -m Development)
* Run yarn start

## For Production
* Switch to the "main" branch (git rebase -m main)
* Run yarn start

